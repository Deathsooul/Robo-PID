ultrasonic-library
==================

Arduino Library to use with the ultrasonic sensor HC-SR04  
Original author
http://blog.iteadstudio.com/arduino-library-for-ultrasonic-ranging-module-hc-sr04/
